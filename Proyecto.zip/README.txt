Este proyecto se realizo para la materia de primer
semestre "Programación de Computadores", fue 
desarrollado en el editor de codigo ATOM, a traves
del lenguaje de programación Pyhton.
Para que pueda ser ejecutado de mejor manera
es necesario abrir la carpeta entera en el editor
de codigo dado que en esta se encuentran todas las 
imagenes necesarias para que el programa se ejecute
de la mejor manera, y unicamente son leidas si estan 
adjuntadas en la misma carpeta que el proyecto.